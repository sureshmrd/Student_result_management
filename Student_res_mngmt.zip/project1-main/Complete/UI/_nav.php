<html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</html>
<?php 

echo '<nav>
<img src="../UI/logo.png" alt="CRRE">
<div class="logo">
    <p class="heading">SIR C R REDDY COLLEGE OF ENGINEERING</p>
   <div> <ul>
        <li><a href="Home.php" target="_top">Home</a></li>
        <li><a href="stuReg.php" target="_top">student</a></li>
        <li><a href="CouncLogin.php" target="_top">counsellors</a></li>
        <li><a href="#" target="_top">HOD</a></li>
        <li><a href="Admin.php" target="_top">Admin</a></li>
    </ul></div>
</div>
    
    
</nav>';
?>